const openBtn = document.getElementById("openBtn");
const cover = document.getElementById("cover");
const surprise = document.getElementById("surprise");
const video = document.getElementById("surpriseVideo");
const videoError = document.getElementById("videoError");

openBtn.addEventListener("click", async () => {
  cover.classList.add("hidden");
  surprise.classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });

  // Try to start the video after a real user tap.
  try {
    video.currentTime = 0;
    await video.play();
  } catch (err) {
    // Some browsers may require the user to press the video play control.
    console.log("Autoplay was blocked:", err);
  }
});

video.addEventListener("error", () => {
  videoError.classList.remove("hidden");
});

video.addEventListener("loadeddata", () => {
  videoError.classList.add("hidden");
});
